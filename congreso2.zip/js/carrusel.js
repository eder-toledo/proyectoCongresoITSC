$(document).ready(function(){
	$(".bxslider").bxSlider();
	});