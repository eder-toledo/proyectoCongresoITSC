
<link href="css/bootstrap.css" rel="stylesheet" media="screen"/>
<link href="css/bootstrap-responsive.css" rel="stylesheet" media="screen"/>


<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<script src="js/jquery-1.10.1.js"></script>

<div class="navbar navbar-inverse">
	<div class="navbar-inner">
		<div class="container">
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="#"><img src="imagenes/logo tec (copia).gif" width="70px" height="70px" /> 2o Congreso Internacional de Ingenierias ITSC</a>
			<div class="nav-collapse collapse">
			<ul class="nav menu">
				<li><a href="index.php">Inicio</a></li>
				<li> <a href="convoca.php">Convocatoria</a> </li> 
				<li> <a href="#">Registro de participantes</a> </li> 
				<li> <a href="#">Ponencias</a> </li>
				<li> <a href="#">Ponentes</a> </li>  
				<li> <a href="#">Comite Organizador</a> </li>
				<li> <a href="envio_trabajos.php">Envio de trabajos</a> </li>
				<li> <a href="noticias.php">Noticias</a> </li>
			</ul>
			</div>
		</div>
	</div>
</div>

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
